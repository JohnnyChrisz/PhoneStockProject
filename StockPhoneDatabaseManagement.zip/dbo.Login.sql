﻿CREATE TABLE [dbo].[Table]
(
	[Username] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [Password] NVARCHAR(50) NOT NULL
)
