﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockPhoneDatabaseManagement
{
    public partial class FindAccessory : Form
    {
        SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString)
        {

        };
        SqlCommand cm = new SqlCommand();
        public FindAccessory()
        {
            InitializeComponent();
        }

        private void FindAccessory_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stockPhoneDatabaseDataSet3.Accessory' table. You can move, or remove it, as needed.
            this.accessoryTableAdapter.Fill(this.stockPhoneDatabaseDataSet3.Accessory);
            dataGrid.Hide();

        }
        private void ShowDataName()
        {
            string sql = "SELECT *FROM Accessory WHERE Name = @Name ";
            cm = new SqlCommand(sql, cn);
            cm.Parameters.AddWithValue("@Name", txtAccessory.Text);
            SqlDataAdapter adapter = new SqlDataAdapter(cm);
            DataTable data = new DataTable();

            dataGrid.Show();
            adapter.Fill(data);
            dataGrid.DataSource = data;

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();
        }


        private void btnSearch_Click(object sender, EventArgs e)
        {
            ShowDataName();
        }

        private void btnSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender,e);
            }
        }

        private void txtAccessory_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender,e);
            }
        }

        private void GoBack_Click(object sender, EventArgs e)
        {
            // Hide the current form (FindPhone)
            this.Hide();

            //// Show the main form if it was already created
            //if (Application.OpenForms["Accessory"] != null)
            //{
            //    Application.OpenForms["Accessory"].Show();
            //}
            //else
            //{
            //    MessageBox.Show("Accessory form not found.");
            //}
        }

        private void FindAccessory_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Hide the current form (FindPhone)
            this.Hide();

            // Show the main form if it was already created
            //if (Application.OpenForms["Accessory"] != null)
            //{
            //    Application.OpenForms["Accessory"].Show();
            //}
            //else
            //{
            //    MessageBox.Show("Accessory form not found.");
            //}
        }
    }
}
