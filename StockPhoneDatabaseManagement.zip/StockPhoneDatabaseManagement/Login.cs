﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockPhoneDatabaseManagement
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            chkHidePassword.CheckedChanged += chkHidePassword_CheckedChanged;
            this.Load += LoginForm_Load;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtPassword.Text;
            string password = txtPassword.Text;

            // Perform your authentication logic here
            bool isAuthenticated = AuthenticateUser(username, password);

            if (isAuthenticated)
            {
                // If authentication succeeds, set the DialogResult to OK
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                // If authentication fails, display an error message
                MessageBox.Show("Invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool AuthenticateUser(string username, string password)
        {
            // Hardcoded authentication for username "admin" and password "admin"
            return username == "admin" && password == "admin";
        }

        private void chkHidePassword_CheckedChanged(object sender, EventArgs e)
        {
            // Show or hide password based on the checkbox state
            if (chkHidePassword.Checked)
                txtPassword.PasswordChar = '*'; // Hide password with asterisks
            else
                txtPassword.PasswordChar = '\0'; // Show plaintext
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Set PasswordChar initially after the form is fully initialized
            txtPassword.PasswordChar = chkHidePassword.Checked ? '*' : '\0';
        }

        private void btnLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Trigger btnLogin_Click event when Enter key is pressed
                btnLogin_Click(sender, e);
            }
        }

        private void txtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Trigger btnLogin_Click event when Enter key is pressed
                btnLogin_Click(sender, e);
            }
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Trigger btnLogin_Click event when Enter key is pressed
                btnLogin_Click(sender, e);
            }
        }
    }
}
