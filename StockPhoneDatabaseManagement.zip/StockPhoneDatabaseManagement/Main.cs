﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockPhoneDatabaseManagement
{
    public partial class Main : Form
    {
        SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString)
        {

        };
        SqlCommand cm = new SqlCommand();
        public Main()
        {
            InitializeComponent();
        }

        private void lookIng_Click(object sender, EventArgs e)
        {
            FindPhone findPhone = new FindPhone();
            findPhone.Show();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            bool loginSuccessful = false;

            // Loop until login is successful or the user closes the application
            while (!loginSuccessful)
            {
                // Show the login form
                LoginForm login = new LoginForm();

                // Check the result of the login form
                if (login.ShowDialog() == DialogResult.OK)
                {
                    // If login is successful, set the flag to true and break the loop
                    loginSuccessful = true;

                }
                else
                {
                    // If login is not successful and the user didn't close the application, show a message and continue the loop
                    if (MessageBox.Show("Login failed. Do you want to try again?", "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) == DialogResult.Cancel)
                    {
                        // If the user chooses not to retry, close the application
                        Application.Exit();
                        return;
                    }
                }
            }

            // If login is successful, load the main form
            this.Show();
            // TODO: This line of code loads data into the 'stockPhoneDatabaseDataSet1.PhoneStock' table. You can move, or remove it, as needed.
            this.phoneStockTableAdapter.Fill(this.stockPhoneDatabaseDataSet1.PhoneStock);
            dataGrid.Hide();
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;

        }

        //private void guna2DataGridView1_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Delete)
        //    {
        //        if (MessageBox.Show("are you sure want to delete this?", "Mesage", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult) phoneStockBindingSource.RemoveCurrent();
        //    }
        //}

        //private void guna2DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (e.RowIndex >= 0 && e.RowIndex < dataGrid.Rows.Count)
        //    {
        //        btnUpdate.Enabled = true;
        //        btnDelete.Enabled = true;

        //        txtName.Text = dataGrid.Rows[e.RowIndex].Cells[1].Value.ToString();
        //        txtModel.Text = dataGrid.Rows[e.RowIndex].Cells[2].Value.ToString();
        //        txtColor.Text = dataGrid.Rows[e.RowIndex].Cells[3].Value.ToString();
        //        txtStorage.Text = dataGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
        //        txtRAM.Text = dataGrid.Rows[e.RowIndex].Cells[5].Value.ToString();
        //        txtYear.Text = dataGrid.Rows[e.RowIndex].Cells[6].Value.ToString();
        //        txtPrice.Text = dataGrid.Rows[e.RowIndex].Cells[7].Value.ToString();
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please Select a Row", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
        //    }
        //}

        private void dataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGrid.Rows.Count)
            {
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;

                txtName.Text = dataGrid.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtModel.Text = dataGrid.Rows[e.RowIndex].Cells[2].Value.ToString();
                txtColor.Text = dataGrid.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtStorage.Text = dataGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtRAM.Text = dataGrid.Rows[e.RowIndex].Cells[5].Value.ToString();
                txtYear.Text = dataGrid.Rows[e.RowIndex].Cells[6].Value.ToString();
                txtPrice.Text = dataGrid.Rows[e.RowIndex].Cells[7].Value.ToString();
            }
            else
            {
                MessageBox.Show("Please Select a Row", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to Exit", "Exit?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            };
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGrid.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    // Get the unique identifier of the record from the selected row
                    int recordId = Convert.ToInt32(dataGrid.SelectedRows[0].Cells[0].Value);

                    // Move the item to the stock out table
                    string moveItemQuery = "INSERT INTO PhoneStockOut (Name, Model, Color, Storage, RAM, Year, Price) " +
                                           "SELECT Name, Model, Color, Storage, RAM, Year, Price FROM PhoneStock WHERE Id = @Id";
                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString))
                    {
                        using (SqlCommand command = new SqlCommand(moveItemQuery, connection))
                        {
                            command.Parameters.AddWithValue("@Id", recordId);
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();
                            connection.Close();

                            if (rowsAffected > 0)
                            {
                                // Delete the item from the stock in table
                                string deleteQuery = "DELETE FROM PhoneStock WHERE Id = @Id";
                                using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                                {
                                    deleteCommand.Parameters.AddWithValue("@Id", recordId);
                                    connection.Open();
                                    deleteCommand.ExecuteNonQuery();
                                    connection.Close();

                                    // Remove the selected row from the DataGridView
                                    dataGrid.Rows.RemoveAt(dataGrid.SelectedRows[0].Index);

                                    MessageBox.Show("Record moved to Stock Out successfully.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Failed to move record to Stock Out.");
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ShowData()
        {
            string sql = "SELECT *FROM PhoneStock";
            cm = new SqlCommand(sql, cn);
            SqlDataAdapter adapter = new SqlDataAdapter(cm);
            DataTable data = new DataTable();

            cn.Open();
            adapter.Fill(data);
            cn.Close();
            dataGrid.DataSource = data;
        }


        private void btnShow_Click(object sender, EventArgs e)
        {
            ShowData();
            dataGrid.Show();
        }
        private void AddNew()
        {
            string sql = "INSERT INTO PhoneStock(Name,Model,Color,Storage,RAM,Year,Price) VALUES (@Name,@Model,@Color,@Storage,@RAM,@Year,@Price)";

            cm = new SqlCommand(sql, cn);

            cm.Parameters.AddWithValue("@Name", txtName.Text);
            cm.Parameters.AddWithValue("@Model", txtModel.Text);
            cm.Parameters.AddWithValue("@Color", txtColor.Text);
            cm.Parameters.AddWithValue("@Storage", txtStorage.Text);
            cm.Parameters.AddWithValue("@RAM", txtRAM.Text);
            cm.Parameters.AddWithValue("@Year", txtYear.Text);
            cm.Parameters.AddWithValue("@Price", txtPrice.Text);

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();
            ClearText();
            ShowData();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void btnGoToAccessory_Click(object sender, EventArgs e)
        {
            Accessory accessory = new Accessory();
            accessory.Show();
        }
        private void ClearText()
        {
            txtName.Text = string.Empty;
            txtModel.Text = string.Empty;
            txtColor.Text = string.Empty;
            txtStorage.Text = string.Empty;
            txtRAM.Text = string.Empty;
            txtYear.Text = string.Empty;
            txtPrice.Text = string.Empty;

        }

        private void Main_Click(object sender, EventArgs e)
        {
            ClearText();
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }
        private void UpdateData()
        {
            if (dataGrid.SelectedRows.Count > 0)
            {
                string selectedId = dataGrid.SelectedRows[0].Cells[0].Value.ToString();

                string sql = "UPDATE PhoneStock SET Name = @Name, Model = @Model, Color = @Color,Storage = @Storage, RAM = @RAM, Year = @Year, Price = @Price WHERE Id = '" + selectedId + "'";
                cm = new SqlCommand(sql, cn);

                cm.Parameters.AddWithValue("@Name", txtName.Text);
                cm.Parameters.AddWithValue("@Model", txtModel.Text);
                cm.Parameters.AddWithValue("@Color", txtColor.Text);
                cm.Parameters.AddWithValue("@Storage", txtStorage.Text);
                cm.Parameters.AddWithValue("@RAM", txtRAM.Text);
                cm.Parameters.AddWithValue("@Year", txtYear.Text);
                cm.Parameters.AddWithValue("@Price", txtPrice.Text);
                cm.Parameters.AddWithValue("@Id", selectedId);

                cn.Open();
                cm.ExecuteNonQuery();
                cn.Close();
                ClearText();
                ShowData();
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }
        //private void UpdateData()
        //{
        //    if (dataGrid.SelectedRows.Count > 0)
        //    {
        //        string selectedId = dataGrid.SelectedRows[0].Cells[0].Value.ToString();
        //        string sql = "UPDATE PhoneStock SET Name = @Name, Model = @Model, Color = @Color,Storage = @Storage, RAM = @RAM, Year = @Year, Price = @Price WHERE Id = '" + selectedId + "'";
        //        cm = new SqlCommand(sql, cn);
                

        //        string updateQueryStockIn = "UPDATE PhoneStockIn " +
        //                                     "SET Name = @Name, Model = @Model, Color = @Color, Storage = @Storage, RAM = @RAM, Year = @Year, Price = @Price " +
        //                                     "WHERE Id = @Id";

        //        //string updateQueryStockOut = "UPDATE PhoneStockOut " +
        //        //                              "SET Name = @Name, Model = @Model, Color = @Color, Storage = @Storage, RAM = @RAM, Year = @Year, Price = @Price " +
        //        //                              "WHERE Id = @Id";

        //        using (SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString))
        //        {
        //            cn.Open();

        //            // Update the item in the stock in table
        //            using (SqlCommand cmIn = new SqlCommand(updateQueryStockIn, cn))
        //            {
        //                cmIn.Parameters.AddWithValue("@Id", selectedId);
        //                cmIn.Parameters.AddWithValue("@Name", txtName.Text);
        //                cmIn.Parameters.AddWithValue("@Model", txtModel.Text);
        //                cmIn.Parameters.AddWithValue("@Color", txtColor.Text);
        //                cmIn.Parameters.AddWithValue("@Storage", txtStorage.Text);
        //                cmIn.Parameters.AddWithValue("@RAM", txtRAM.Text);
        //                cmIn.Parameters.AddWithValue("@Year", txtYear.Text);
        //                cmIn.Parameters.AddWithValue("@Price", txtPrice.Text);

        //                int rowsAffectedStockIn = cmIn.ExecuteNonQuery();

        //                //Update the item in the PhoneStock table
        //                using (SqlCommand cm = new SqlCommand(sql, cn))
        //                {
        //                    cm.Parameters.AddWithValue("@Id", selectedId);
        //                    cm.Parameters.AddWithValue("@Name", txtName.Text);
        //                    cm.Parameters.AddWithValue("@Model", txtModel.Text);
        //                    cm.Parameters.AddWithValue("@Color", txtColor.Text);
        //                    cm.Parameters.AddWithValue("@Storage", txtStorage.Text);
        //                    cm.Parameters.AddWithValue("@RAM", txtRAM.Text);
        //                    cm.Parameters.AddWithValue("@Year", txtYear.Text);
        //                    cm.Parameters.AddWithValue("@Price", txtPrice.Text);

        //                    int rowsAffectedPhoneStock = cm.ExecuteNonQuery();

        //                    if (rowsAffectedStockIn > 0 && rowsAffectedPhoneStock > 0)
        //                    {
        //                        MessageBox.Show("Record updated successfully.");
        //                        ClearText();
        //                        ShowData(); // Optional: Refresh the DataGridView to reflect           changes
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("Failed to update record.");
        //                    }
        //                }
        //            }

        //            cn.Close();
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please select a row to update.");
        //    }
        //}


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateData();
            ClearText();
        }

        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGrid.Rows.Count)
            {
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;

                txtName.Text = dataGrid.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtModel.Text = dataGrid.Rows[e.RowIndex].Cells[2].Value.ToString();
                txtColor.Text = dataGrid.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtStorage.Text = dataGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtRAM.Text = dataGrid.Rows[e.RowIndex].Cells[5].Value.ToString();
                txtYear.Text = dataGrid.Rows[e.RowIndex].Cells[6].Value.ToString();
                txtPrice.Text = dataGrid.Rows[e.RowIndex].Cells[7].Value.ToString();
            }
            else
            {
                MessageBox.Show("Please Select a Row", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }
        }

        private void dataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {

                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    // Get the unique identifier of the record from the selected row
                    int recordId = Convert.ToInt32(dataGrid.SelectedRows[0].Cells[0].Value);

                    // Move the item to the stock out table
                    string sqlOut = "INSERT INTO PhoneStockOut (Name, Model, Color, Storage, RAM, Year, Price) " +
                                           "SELECT Name, Model, Color, Storage, RAM, Year, Price FROM PhoneStock WHERE Id = @Id";
                    using (SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString))
                    {
                        using (SqlCommand cmOut = new SqlCommand(sqlOut, cn))
                        {
                            cmOut.Parameters.AddWithValue("@Id", recordId);
                            cn.Open();
                            int rowsAffected = cmOut.ExecuteNonQuery();
                            cn.Close();

                            if (rowsAffected > 0)
                            {
                                // Delete the item from the stock in table
                                string sql = "DELETE FROM PhoneStock WHERE Id = @Id";
                                using (SqlCommand cm = new SqlCommand(sql, cn))
                                {
                                    cm.Parameters.AddWithValue("@Id", recordId);
                                    cn.Open();
                                    cm.ExecuteNonQuery();
                                    cn.Close();

                                    // Remove the selected row from the DataGridView
                                    dataGrid.Rows.RemoveAt(dataGrid.SelectedRows[0].Index);

                                    MessageBox.Show("Record moved to Stock Out successfully.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Failed to move record to Stock Out.");
                            }
                        }
                    }
                }
            }
        }

        private void StockIn_Click(object sender, EventArgs e)
        {
            StockIn stockIn = new StockIn();
            stockIn.Show();
        }

        private void StockOut_Click(object sender, EventArgs e)
        {
            PhoneStockOut stockOut = new PhoneStockOut();
            stockOut.Show();
        }
    }
}
