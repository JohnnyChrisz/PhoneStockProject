﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Management;
using System.Diagnostics;

namespace StockPhoneDatabaseManagement
{
    public partial class Accessory : Form
    {
        SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString)
        {

        };
        SqlCommand cm = new SqlCommand();
        public Accessory()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stockPhoneDatabaseDataSet.Accessory' table. You can move, or remove it, as needed.
            this.accessoryTableAdapter.Fill(this.stockPhoneDatabaseDataSet.Accessory);
            dataGrid.Hide();
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;


        }
        private void UpdateData()
        {
            if (dataGrid.SelectedRows.Count > 0)
            {
                string selectedId = dataGrid.SelectedRows[0].Cells[0].Value.ToString();

                string sql = "UPDATE Accessory SET Name = @Name, Color = @Color, Type = @Type, Amount = @Amount, Price = @Price WHERE Id = '" + selectedId + "'";
                cm = new SqlCommand(sql, cn);

                cm.Parameters.AddWithValue("@Name", txtName.Text);
                cm.Parameters.AddWithValue("@Color", txtColor.Text);
                cm.Parameters.AddWithValue("@Type", txtType.Text);
                cm.Parameters.AddWithValue("@Amount", txtAmount.Text);
                cm.Parameters.AddWithValue("@Price", txtPrice.Text);
                cm.Parameters.AddWithValue("@Id", selectedId);

                cn.Open();
                cm.ExecuteNonQuery();
                cn.Close();
                ClearText();
                ShowData();
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }
        private void ClearText()
        {
            txtName.Text = string.Empty;
            txtColor.Text = string.Empty;
            txtType.Text = string.Empty;
            txtAmount.Text = string.Empty;
            txtPrice.Text = string.Empty;

        }

        private void ShowData()
        {
            string sql = "SELECT *FROM Accessory";
            cm = new SqlCommand(sql, cn);
            SqlDataAdapter adapter = new SqlDataAdapter(cm);
            DataTable data = new DataTable();

            cn.Open();
            adapter.Fill(data);
            cn.Close();
            dataGrid.DataSource = data;
        }
        //private void DeleteData()
        //{
        //    if (dataGrid.SelectedRows.Count > 0)
        //    {
        //        DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);

        //        if (result == DialogResult.Yes)
        //        {
        //            // Get the unique identifier of the record from the selected row
        //            int recordId = Convert.ToInt32(dataGrid.SelectedRows[0].Cells[0].Value);

        //            // Move the item to the stock out table
        //            string moveItemQuery = "INSERT INTO AccessoryStockOut(Name, Color, Type, Amount, Price) VALUES(@Name, @Color, @Type, @Amount, @Price)" +
        //                                   "SELECT Name, Color, Type, Amount, Price FROM Accessory WHERE Id = @Id";
        //            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString))
        //            {
        //                using (SqlCommand command = new SqlCommand(moveItemQuery, connection))
        //                {
        //                    command.Parameters.AddWithValue("@Id", recordId);
        //                    connection.Open();
        //                    int rowsAffected = command.ExecuteNonQuery();
        //                    connection.Close();

        //                    if (rowsAffected > 0)
        //                    {
        //                        // Delete the item from the stock in table
        //                        string deleteQuery = "DELETE FROM Accessory WHERE Id = @Id";
        //                        using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
        //                        {
        //                            deleteCommand.Parameters.AddWithValue("@Id", recordId);
        //                            connection.Open();
        //                            deleteCommand.ExecuteNonQuery();
        //                            connection.Close();

        //                            // Remove the selected row from the DataGridView
        //                            dataGrid.Rows.RemoveAt(dataGrid.SelectedRows[0].Index);

        //                            MessageBox.Show("Record moved to Stock Out successfully.");
        //                        }
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("Failed to move record to Stock Out.");
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //}
        private void DeleteData()
        {
            if (dataGrid.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    // Get the unique identifier of the record from the selected row
                    int recordId = Convert.ToInt32(dataGrid.SelectedRows[0].Cells[0].Value);

                    // Move the item to the stock out table
                    string moveItemQuery = "INSERT INTO AccessoryStockOut(Name, Color, Type, Amount, Price) " +
                                           "SELECT Name, Color, Type, Amount, Price FROM Accessory WHERE Id = @Id";
                    string deleteQuery = "DELETE FROM Accessory WHERE Id = @Id";

                    using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString))
                    {
                        connection.Open();

                        // Move the item to stock out
                        using (SqlCommand moveCommand = new SqlCommand(moveItemQuery, connection))
                        {
                            moveCommand.Parameters.AddWithValue("@Id", recordId);
                            int rowsAffected = moveCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                // Delete the item from stock in
                                using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                                {
                                    deleteCommand.Parameters.AddWithValue("@Id", recordId);
                                    deleteCommand.ExecuteNonQuery();

                                    // Remove the selected row from the DataGridView
                                    dataGrid.Rows.RemoveAt(dataGrid.SelectedRows[0].Index);

                                    MessageBox.Show("Record moved to Stock Out successfully.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Failed to move record to Stock Out.");
                            }
                        }

                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnGoBack_Click(object sender, EventArgs e)
        {
            // Hide the current form (FindPhone)
            this.Hide();

            // Show the main form if it was already created
            if (Application.OpenForms["Main"] != null)
            {
                Application.OpenForms["Main"].Show();
            }
            else
            {
                MessageBox.Show("Main form not found.");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteData();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            ShowData();
            dataGrid.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateData();
            ClearText();
        }
        private void AddNew()
        {
            string sql = "INSERT INTO Accessory(Name,Color,Type,Amount,Price) VALUES (@Name,@Color,@Type,@Amount,@Price)";
            cm = new SqlCommand(sql, cn);

            cm.Parameters.AddWithValue("@Name", txtName.Text);
            cm.Parameters.AddWithValue("@Color", txtColor.Text);
            cm.Parameters.AddWithValue("@Type", txtType.Text);
            cm.Parameters.AddWithValue("@Amount", txtAmount.Text);
            cm.Parameters.AddWithValue("@Price", txtPrice.Text);

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();
            ClearText();
            ShowData();

        }


        private void btnAddNew_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void Accessory_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms["Main"] != null)
            {
                Application.OpenForms["Main"].Show();
            }
            else
            {
                // Create an instance of the main form if it wasn't already created
                Main mainForm = new Main();
                mainForm.Show();
            }
        }

        private void GoBackbtn_Click(object sender, EventArgs e)
        {
            // Hide the current form (FindPhone)
            this.Hide();

            // Show the main form if it was already created
            if (Application.OpenForms["Main"] != null)
            {
                Application.OpenForms["Main"].Show();
            }
            else
            {
                MessageBox.Show("Main form not found.");
            }
        }

        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGrid.Rows.Count)
            {
                txtName.Text = dataGrid.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtColor.Text = dataGrid.Rows[e.RowIndex].Cells[2].Value.ToString();
                txtType.Text = dataGrid.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtAmount.Text = dataGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
                txtPrice.Text = dataGrid.Rows[e.RowIndex].Cells[5].Value.ToString();
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                MessageBox.Show("Please Select a Row", "Message", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }
        }

        private void Accessory_Click(object sender, EventArgs e)
        {
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
            ClearText();
        }

        private void dataGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                btnDelete_Click(sender, e);
            }
        }

        private void LookingAccessory_Click(object sender, EventArgs e)
        {
            FindAccessory findAccessory = new FindAccessory();
            findAccessory.Show();
        }

        private void StockIn_Click(object sender, EventArgs e)
        {
            AccessoryStockIn accessoryStockIn = new AccessoryStockIn();
            accessoryStockIn.Show();
        }

        private void StockOut_Click(object sender, EventArgs e)
        {
            AccessoryStockOut accessoryStockOut = new AccessoryStockOut();
            accessoryStockOut.Show();
        }
    }
}
