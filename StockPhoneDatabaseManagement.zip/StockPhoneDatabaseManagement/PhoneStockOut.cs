﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockPhoneDatabaseManagement
{
    public partial class PhoneStockOut : Form
    {
        SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString)
        {

        };
        SqlCommand cm = new SqlCommand();
        public PhoneStockOut()
        {
            InitializeComponent();
        }

        private void PhoneStockOut_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stockPhoneDatabaseDataSet5.PhoneStockOut' table. You can move, or remove it, as needed.
            this.phoneStockOutTableAdapter.Fill(this.stockPhoneDatabaseDataSet5.PhoneStockOut);
            dataGrid.Hide();

        }

        private void PhoneStockOut_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms["Main"] != null)
            {
                Application.OpenForms["Main"].Show();
            }
            else
            {
                // Create an instance of the main form if it wasn't already created
                Main mainForm = new Main();
                mainForm.Show();
            }
        }
        private void ShowData()
        {
            string sql = "SELECT *FROM PhoneStockOut";
            cm = new SqlCommand(sql, cn);
            SqlDataAdapter adapter = new SqlDataAdapter(cm);
            DataTable data = new DataTable();

            cn.Open();
            adapter.Fill(data);
            cn.Close();
            dataGrid.Show();
            dataGrid.DataSource = data;
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            ShowData();
        }
    }
}
