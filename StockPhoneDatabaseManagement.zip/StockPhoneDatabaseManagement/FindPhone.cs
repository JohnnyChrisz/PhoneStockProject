﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockPhoneDatabaseManagement
{
    public partial class FindPhone : Form
    {
        SqlConnection cn = new SqlConnection(Properties.Settings.Default.StockPhoneDatabaseConnectionString)
        {

        };
        SqlCommand cm = new SqlCommand();
        public FindPhone()
        {
            InitializeComponent();

        }
      
        private void FindPhone_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stockPhoneDatabaseDataSet2.PhoneStock' table. You can move, or remove it, as needed.
            this.phoneStockTableAdapter.Fill(this.stockPhoneDatabaseDataSet2.PhoneStock);
            dataGrid.Hide();

        }

        private void GoBack_Click(object sender, EventArgs e)
        {
            // Hide the current form (FindPhone)
            this.Hide();

            // Show the main form if it was already created
            if (Application.OpenForms["Main"] != null)
            {
                Application.OpenForms["Main"].Show();
            }
            else
            {
                MessageBox.Show("Main form not found.");
            }
        }
        private void ShowDataName()
        {
            string sql = "SELECT *FROM PhoneStock WHERE Name = @Name ";
            cm = new SqlCommand(sql, cn);
            cm.Parameters.AddWithValue("@Name", txtSearchPName.Text);
            SqlDataAdapter adapter = new SqlDataAdapter(cm);
            DataTable data = new DataTable();

            dataGrid.Show();
            adapter.Fill(data);
            dataGrid.DataSource = data;

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            ShowDataName();
        }

        private void FindPhone_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Application.OpenForms["Main"] != null)
            {
                Application.OpenForms["Main"].Show();
            }
            else
            {
                // Create an instance of the main form if it wasn't already created
                Main mainForm = new Main();
                mainForm.Show();
            }
        }

        private void btnSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string sql = "SELECT *FROM PhoneStock WHERE Name = @Name ";
                cm = new SqlCommand(sql, cn);
                cm.Parameters.AddWithValue("@Name", txtSearchPName.Text);
                SqlDataAdapter adapter = new SqlDataAdapter(cm);
                DataTable data = new DataTable();

                dataGrid.Show();
                adapter.Fill(data);
                dataGrid.DataSource = data;

                cn.Open();
                cm.ExecuteNonQuery();
                cn.Close();
            }
        }

        private void txtSearchPName_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }
    }
}
