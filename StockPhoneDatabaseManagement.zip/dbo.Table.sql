﻿CREATE TABLE Accessory
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1), 
    [Name] NVARCHAR(250) NULL, 
    [Color] NVARCHAR(250) NULL, 
    [Type] NVARCHAR(250) NULL, 
    [Amount] NVARCHAR(250) NULL, 
    [Price] NVARCHAR(250) NULL
)
