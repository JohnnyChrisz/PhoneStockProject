﻿CREATE TABLE [dbo].[PhoneStock] (
    [Id]      INT            IDENTITY (1, 1) NOT NULL,
    [Name]    NVARCHAR (250) NOT NULL,
    [Model]   NVARCHAR (250) NULL,
    [Color]   NVARCHAR (250) NULL,
    [Storage] NVARCHAR (250) NULL,
    [RAM]     NVARCHAR (250) NULL,
    [Year]    INT NULL,
    [Price]   MONEY NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

